// +build !linux

package main

import (
	"fmt"
)

func main() {
	fmt.Println("This command is only available on Linux")
}
