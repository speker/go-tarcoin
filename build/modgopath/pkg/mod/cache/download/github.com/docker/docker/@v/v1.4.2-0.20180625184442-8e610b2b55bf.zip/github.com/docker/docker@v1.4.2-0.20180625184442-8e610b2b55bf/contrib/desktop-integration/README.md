Desktop Integration
===================

The ./contrib/desktop-integration contains examples of typical dockerized
desktop applications.

Examples
========

* Chromium: ./chromium/Dockerfile shows a way to dockerize a common application
* Gparted: ./gparted/Dockerfile shows a way to dockerize a common application w devices
