// +build arm

package binfmt_misc

func armSupported() error {
	return nil
}
