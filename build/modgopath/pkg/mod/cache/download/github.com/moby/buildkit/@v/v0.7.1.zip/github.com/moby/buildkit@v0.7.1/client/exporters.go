package client

const (
	ExporterImage  = "image"
	ExporterLocal  = "local"
	ExporterTar    = "tar"
	ExporterOCI    = "oci"
	ExporterDocker = "docker"
)
