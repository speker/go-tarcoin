// +build arm64

package binfmt_misc

func arm64Supported() error {
	return nil
}
