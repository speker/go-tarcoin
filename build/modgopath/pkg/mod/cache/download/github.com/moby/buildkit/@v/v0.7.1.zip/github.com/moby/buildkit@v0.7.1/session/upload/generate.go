package upload

//go:generate protoc --gogoslick_out=plugins=grpc:. upload.proto
