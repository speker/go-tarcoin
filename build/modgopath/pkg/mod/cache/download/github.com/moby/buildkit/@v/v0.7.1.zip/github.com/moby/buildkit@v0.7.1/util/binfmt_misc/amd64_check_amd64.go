// +build amd64

package binfmt_misc

func amd64Supported() error {
	return nil
}
