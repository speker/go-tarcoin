package sshforward

//go:generate protoc --gogoslick_out=plugins=grpc:. ssh.proto
