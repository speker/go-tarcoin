# Dockerfile frontend experimental syntaxes

Documentation for experimental Dockerfile syntaxes can be found in the
[Dockerfile frontend documentation](/frontend/dockerfile/docs/experimental.md)
