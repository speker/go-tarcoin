// +build riscv64

package binfmt_misc

func riscv64Supported() error {
	return nil
}
