package contenthash

//go:generate protoc -I=. -I=../../vendor/ --gogofaster_out=. checksum.proto
