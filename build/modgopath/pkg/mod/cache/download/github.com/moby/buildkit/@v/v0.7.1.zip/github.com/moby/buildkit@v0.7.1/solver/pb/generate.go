package pb

//go:generate protoc -I=. -I=../../vendor/ --gogofaster_out=. ops.proto
