package secrets

//go:generate protoc --gogoslick_out=plugins=grpc:. secrets.proto
